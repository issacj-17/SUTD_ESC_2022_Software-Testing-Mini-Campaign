
import java.io.*;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ProgramCheck {

    @Test
    // Compare Files With Different Record Size
    public void test1() throws Exception {
        String filename = "input_files\\test1-control.csv" + System.lineSeparator() + "input_files\\test2-different-record-size.csv" + System.lineSeparator();
        System.out.println(filename);
        ByteArrayInputStream input = new ByteArrayInputStream(filename.getBytes());
        System.setIn(input);
        Scanner sc1 = new Scanner (System.in);
        CompareCSV.main(null);

        String absPath = new File("").getAbsolutePath();

        Path expected = Paths.get(absPath + ".\\expected\\test1-test2-output.csv");
        Path actual = Paths.get(absPath + ".\\output.csv");
        assertEquals(-1, Files.mismatch(expected, actual));
    }

    @Test
    // Compare Files with Different Column Order
    public void test2() throws Exception {
        String filename = "input_files\\test1-control.csv" + System.lineSeparator() + "input_files\\test3-different-order-columns.csv" + System.lineSeparator();
        System.out.println(filename);
        ByteArrayInputStream input = new ByteArrayInputStream(filename.getBytes());
        System.setIn(input);
        Scanner sc1 = new Scanner (System.in);
        CompareCSV.main(null);

        String absPath = new File("").getAbsolutePath();

        Path expected = Paths.get(absPath + ".\\expected\\test1-test3-output.csv");
        Path actual = Paths.get(absPath + ".\\output.csv");
        assertEquals(-1, Files.mismatch(expected, actual));
    }

    @Test
    // Compare Files with Different Column Order for Customer ID#
    public void test3() throws Exception {
        String filename = "input_files\\test1-control.csv" + System.lineSeparator() + "input_files\\test4-different-order-customer.csv" + System.lineSeparator();
        System.out.println(filename);
        ByteArrayInputStream input = new ByteArrayInputStream(filename.getBytes());
        System.setIn(input);
        Scanner sc1 = new Scanner (System.in);
        CompareCSV.main(null);

        String absPath = new File("").getAbsolutePath();

        Path expected = Paths.get(absPath + ".\\expected\\test1-test4-output.csv");
        Path actual = Paths.get(absPath + ".\\output.csv");
        assertEquals(-1, Files.mismatch(expected, actual));
    }

}
