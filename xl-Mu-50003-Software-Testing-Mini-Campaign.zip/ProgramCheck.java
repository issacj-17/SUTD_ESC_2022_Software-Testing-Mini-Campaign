package Code;

import java.io.*;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ProgramCheck {

    @Before
    public void setup() {
        System.out.printf("Setting up Test: %s%n", this.getClass().getSimpleName());
    }

    @After
    public void teardown() {
        System.out.printf("Tear Down Test: %s \n%n", this.getClass().getSimpleName());
    }

    @Test
    // Check for Duplicate Rows
    public void test1() throws Exception {
        String filename = ".\\input_files\\test1-control.csv" + System.lineSeparator() + ".\\input_files\\test2-duplicate-rows.csv" + System.lineSeparator();
        System.out.println(filename);
        ByteArrayInputStream input = new ByteArrayInputStream(filename.getBytes());
        System.setIn(input);
        Scanner sc1 = new Scanner (System.in);
        CompareCSV.main(null);

        String absPath = new File("").getAbsolutePath();

        Path expected = Paths.get(absPath + ".\\expected\\test1-test2-output.csv");
        Path actual = Paths.get(absPath + "\\output.csv");
        assertEquals(-1, Files.mismatch(expected, actual));
    }

    @Test
    // Check between Files of Different Record Sizes
    public void test2() throws Exception {
        String filename = ".\\input_files\\test1-control.csv" + System.lineSeparator() + ".\\input_files\\test3-different-record-size.csv" + System.lineSeparator();
        System.out.println(filename);
        ByteArrayInputStream input = new ByteArrayInputStream(filename.getBytes());
        System.setIn(input);
        Scanner sc1 = new Scanner (System.in);
        CompareCSV.main(null);

        String absPath = new File("").getAbsolutePath();

        Path expected = Paths.get(absPath + ".\\expected\\test1-test3-output.csv");
        Path actual = Paths.get(absPath + "\\output.csv");
        assertEquals(-1, Files.mismatch(expected, actual));
    }

    @Test
    // Check between Different Order of Columns
    public void test3() throws Exception {
        String filename = ".\\input_files\\test1-control.csv" + System.lineSeparator() + ".\\input_files\\test4-different-order-columns.csv" + System.lineSeparator();
        System.out.println(filename);
        ByteArrayInputStream input = new ByteArrayInputStream(filename.getBytes());
        System.setIn(input);
        Scanner sc1 = new Scanner (System.in);
        CompareCSV.main(null);

        String absPath = new File("").getAbsolutePath();

        Path expected = Paths.get(absPath + ".\\expected\\test1-test4-output.csv");
        Path actual = Paths.get(absPath + "\\output.csv");
        assertEquals(-1, Files.mismatch(expected, actual));
    }

    @Test
    // Check between Different Order of Rows
    public void test4() throws Exception {
        String filename = ".\\input_files\\test1-control.csv" + System.lineSeparator() + ".\\input_files\\test5-different-order-rows.csv" + System.lineSeparator();
        System.out.println(filename);
        ByteArrayInputStream input = new ByteArrayInputStream(filename.getBytes());
        System.setIn(input);
        Scanner sc1 = new Scanner (System.in);
        CompareCSV.main(null);

        String absPath = new File("").getAbsolutePath();

        Path expected = Paths.get(absPath + ".\\expected\\test1-test5-output.csv");
        Path actual = Paths.get(absPath + "\\output.csv");
        assertEquals(-1, Files.mismatch(expected, actual));
    }

}
